package org.apache.logging.log4j;

// Jar Hell !
public class Logger {

}

