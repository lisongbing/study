import org.apache.logging.log4j.LogManager;

public class TestingLog4j {
    public TestingLog4j() {
        LogManager.getLogger();
    }
}
