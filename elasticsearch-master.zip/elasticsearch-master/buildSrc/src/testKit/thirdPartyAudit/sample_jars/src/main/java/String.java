class String {

}
